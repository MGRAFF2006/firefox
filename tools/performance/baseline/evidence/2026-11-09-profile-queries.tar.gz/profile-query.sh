#!/usr/bin/env bash
set -euo pipefail
export PROFILER_CLI_SESSION_DIR=/srv/development/build/firefox-perf/profiler-sessions
exec /srv/development/build/firefox-perf/profiler-cli/node_modules/.bin/profiler-cli "$@" --session firefox-build-baseline-source
