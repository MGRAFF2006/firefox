#!/usr/bin/env bash
set -euo pipefail
if [[ ${1:-} == load ]]; then
    shift
    exec /srv/development/build/firefox-perf/state/samply/samply load --symbol-dir /srv/development/build/firefox-perf/binaries/source-stock-6181e6b5/symbols "$@"
fi
exec /srv/development/build/firefox-perf/state/samply/samply "$@"
